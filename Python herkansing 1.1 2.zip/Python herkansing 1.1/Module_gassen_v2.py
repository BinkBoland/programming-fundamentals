#Module gassen
import numpy as np 
#bestanden 
gassen_bestand = 'gassen.csv'

# Constanten waardes van de gassen 
c1 = 1
c2 = 25
c3 = 5
c4 = 1000

# gassendata naar een numpy array
gassen_data = np.loadtxt(gassen_bestand, delimiter=",", skiprows=1)

# Functie om totale uitstoot over coordinaten te berekenen
def bereken_uitstoot(Lengte,Breedte):
    gassenarray_1 = gassen_data[:,2].reshape((100,100)) 
    gassenarray_2 = gassen_data[:,3].reshape((100,100))
    gassenarray_3 = gassen_data[:,4].reshape((100,100))
    gassenarray_4 =gassen_data[:,5].reshape((100,100))

    uitstoot = gassenarray_1 *c1 + gassenarray_2 *c2 + gassenarray_3 *c3 + gassenarray_4 *c4

    return uitstoot[Lengte,Breedte]

# deze functie zal de uitstoot berekenenen voor de eerste laag van de coordinaten
def bereken_uitstoot_laag1(Lengte,Breedte):
    gassenarray_1 = gassen_data[:,2].reshape((100,100)) 
    gassenarray_2 = gassen_data[:,3].reshape((100,100))
    gassenarray_3 = gassen_data[:,4].reshape((100,100))
    gassenarray_4 =gassen_data[:,5].reshape((100,100))

    uitstoot = gassenarray_1*c1 + gassenarray_2 *c2 + gassenarray_3 *c3 + gassenarray_4 *c4

    return uitstoot[Lengte -1, Breedte -1] *8/2

# deze functie zal de uitstoot gaan berekenen voor de tweede laag van de coordinaten
def bereken_uitstoot_laag2(Lengte,Breedte):
    gassenarray_1 = gassen_data[:,2].reshape((100,100)) 
    gassenarray_2 = gassen_data[:,3].reshape((100,100))
    gassenarray_3 = gassen_data[:,4].reshape((100,100))
    gassenarray_4 =gassen_data[:,5].reshape((100,100))
    
    uitstoot = gassenarray_1*c1 + gassenarray_2 *c2 + gassenarray_3 *c3 + gassenarray_4 *c4

    return uitstoot[Lengte -2, Breedte -2] *16/4

# deze functie zal de coordinaten vinden met een uitstoot hoger dan de drempelwaarde 
def vind_te_hoge_uitstoot(gassen_data,drempelwaarde):
    gassenarray_1 = gassen_data[:,2].reshape((100,100)) 
    gassenarray_2 = gassen_data[:,3].reshape((100,100))
    gassenarray_3 = gassen_data[:,4].reshape((100,100))
    gassenarray_4 =gassen_data[:,5].reshape((100,100))
    
    uitstoot = gassenarray_1*c1 + gassenarray_2 *c2 + gassenarray_3 *c3 + gassenarray_4 *c4

    #deze functie zal de coordinaten geven van het bedrijf met een waarde hooger dan de drempelwaarde
    te_hoge_uitstoot_coordinaten = np.where(uitstoot>drempelwaarde)

    return list(zip(te_hoge_uitstoot_coordinaten[0], te_hoge_uitstoot_coordinaten[1]))
#vastleggen drempelwaarde 
drempelwaarde = 7000
te_hoge_uitstoot_coordinaten = vind_te_hoge_uitstoot(gassen_data, drempelwaarde)