# module_menu.py
#importeren van alle modules

import module_inspecteurs_v2 as mi
import module_metingen    as mm
import Module_gassen_v2 as gs
import Module_bedrijven_v2 as mb
import Module_rapporten as mr
import Module_ONBEKEND_BEDRIJF as mob
 
while True :
    print('\nHoofdmenu\n=========')
    print('1. Inlezen bestanden')
    print('2. Inlezen en tonen CO2 data')
    print('3. tonen bedrijfsbestand')
    print('4. tonen bezoekrapporten')
    print('5. tonen inspecteursbestand')
    print('6. Bezoekrapport per bedrijf ')
    print('7. Bezoekrapport per inspecteur')
    print('8. Tonen onbekend bedrijf')
    print('0. stoppen\n')

#vragen aan de gebruiker voor een keuze te kiezen van het menu
    try :
        keuze = int(input('Uw keuze : '))
    except ValueError :
        keuze = -1

   
    if keuze == 1:
        mi.lees_inspecteurs()
        mb.lees_bedrijven()
        mr.lees_bezoekrapporten()
    elif keuze == 2 :
    #2. lezen en tonen van de Co2 data    
        mm.lees_gas_co2()
    elif keuze == 3 :
    #3.inlezen en tonen van de bedrijvenbestanden    
       #mb.lees_bedrijven()
        mb.toon_bedrijven()
    elif keuze == 4 :
    #4.inlezen en tonen bezoeksrapporten 
        mr.toon_bezoekrapporten() 
    elif keuze == 5 :
        mi.toon_inspecteurs()
    #5. tonen inspecteursbestand    
        
    elif keuze == 6 :
    #6. bezoekrapporten per bedrijf 
        
        mr.zoek_bedrijf_code()
    elif keuze == 7 :
    #7. bezoekrapporten per inspecteur
        
        mr.Zoek_Inspecteur_code()
    elif keuze == 8 :
    #8. onbekend bedrijf tonen
        mob.tonenOnbekend()
    elif keuze == 0 :
        break
    else :
        print('ongeldige keuze')