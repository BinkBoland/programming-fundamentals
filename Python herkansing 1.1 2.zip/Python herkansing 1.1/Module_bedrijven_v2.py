import Module_gassen_v2 as gs 
#constante voor het bestand bedrijven.txt
Bedrijvenbestand = 'bedrijven.txt'

#boete vaststellen per overchrijding 
BOETE_PER_OVERSCHRIJDING = 100

#list waar het bedrijfsobjecten opgeslagen worden 
lijst_bedrijven = []

#functie om bedrijfsgegevens intelezen uit een .txt bestand 
def lees_bedrijven():
    try: 
        with open(Bedrijvenbestand, mode="r" ) as bedrijven:
            for record in bedrijven: 
                            #uitlezen wat er op de caracterposities staat in het tekstbestand om het uit te lezen.                
                code = record[0:4]
                naam = record[4:24]
                straat = record[24:44]
                huisnr = record[44:59]
                postcode = record[59:66]
                plaats = record[66:80]
                lengtegraad = round(int(record[87:89]), 2)  #afronden op 2
                breedtegraad = round(int(record[89:93]), 2)  
                maxUitstoot = round(int(record[93:99]), 2) 
                controle = record[135:138]
                inspectieFrequentie = record[138:141]
                contactpersoon = record[141:160]
                
                bedrijf = Bedrijf(code, naam, straat, huisnr, postcode, plaats, lengtegraad, breedtegraad,
                                  maxUitstoot, controle, inspectieFrequentie, contactpersoon)
        print("bestand", Bedrijvenbestand, "ingelezen")
        return 0 
    except FileNotFoundError:
        print("bestand", Bedrijvenbestand, "niet gevonden!")
        return 1
    
#deze functie zal een overzicht tonen van de bedrijfsgegevens
def toon_bedrijven():
        print("        Overzicht bedrijven")    
        print("        =====================\n")
        print("Code Naam                 Straat                   Huisnummer Postcode Plaats        Coördinaten Maximale uitstoot Berekenende Uitstoot Boete        Controle     Inspectie Frequentie Contactpersoon")
        print("---- -------------------- ------------------------ ---------- -------- ------------- ----------- ----------------- -------------------- -----------  ------------ -------------------- ---------------------")

        #de onderstaande functie zal de uitstoot gaan berekenen  van de bedrijven op basis van de coordinaten van het bedrijf
        for bedrijf in lijst_bedrijven:
                uitstoot = gs.bereken_uitstoot(bedrijf.getLengte(), bedrijf.getBreedte())
                uitstoot_laag_1 = gs.bereken_uitstoot_laag1(bedrijf.getLengte(), bedrijf.getBreedte())
                uitstoot_laag_2 = gs.bereken_uitstoot_laag2(bedrijf.getLengte(), bedrijf.getBreedte())

                #de volgende functie berekent de totale uitstoot en stelt en boete op
                totale_uitstoot = round(uitstoot + uitstoot_laag_1 + uitstoot_laag_2, 2)
                bedrijf.setBerekendeUitstoot(totale_uitstoot)

                if totale_uitstoot > int(bedrijf.getMaxUitstoot()):
                        overschrijding = round(totale_uitstoot - int(bedrijf.getMaxUitstoot()), 2)
                        boete = round(overschrijding *BOETE_PER_OVERSCHRIJDING,2)
                else: 
                        boete = 0
                bedrijf.setBoete(boete)

                bedrijf.toonGegevens()

#een klasse voor het object bedrijf
#het probleem was dat de defenities binnen de class Bedrijf niet aangeroepen werden omdat ze buiten de class aangeroepen werden. dit probleem is verholpen door de indentatiefout op te lossen. 
class Bedrijf:
        def __init__(self, code, naam='', straat='', huisnummer='', postcode='', plaats='', lengte='', breedte='',
                 maxUitstoot='', controle='', inspectieFrequentie='', contactpersoon='', berekendeUitstoot='', boete=''):

            global lijst_bedrijven     
                # attributen binnen de klasse Bedrijf
            self.__code = code
            self.__naam = naam
            self.__straat = straat
            self.__huisnummer = huisnummer
            self.__postcode = postcode
            self.__plaats = plaats
            self.__lengte = lengte
            self.__breedte = breedte
            self.__maxUitstoot = maxUitstoot
            self.__berekendeUitstoot = berekendeUitstoot
            self.__boete = boete
            self.__controle = controle
            self.__inspectieFrequentie = inspectieFrequentie
            self.__contactpersoon = contactpersoon
            self.__bezoekrapporten = []
            lijst_bedrijven.append(self)

    #    #get en set voor de attributen

        def getCode(self):
                return  self.__code
        def setCode(self, code):
                self.__code  = code

        def getNaam(self):
                return self.__naam
        def setNaam(self, naam):
                self.__naam = naam

        def getStraat(self):
                return self.__straat
        def setStraat(self, straat):
                self.__straat = straat

        def getHuisnummer(self):
                return self.__huisnummer
        def setHuisnummer(self, huisnummer):
                self.__huisnummer = huisnummer

        def getPostcode(self):
                return self.__postcode
        def setPostcode(self, postcode):
                self.__postcode = postcode

        def getPlaats(self):
                return self.__plaats
        def setPlaats(self, plaats):
                self.__plaats = plaats

        def getLengte(self):
                return self.__lengte
        def setLengte(self, lengte):
                self.__lengte = lengte

        def getBreedte(self):
                return self.__breedte
        def setBreedte(self, breedte):
                self.__breedte = breedte

        def getMaxUitstoot(self):
                return self.__maxUitstoot
        def setMaxUitstoot(self, maxUitstoot):
                self.__maxUitstoot = maxUitstoot

        def getBerekendeUitstoot(self):
                return self.__berekendeUitstoot
        def setBerekendeUitstoot(self, uitstoot):
                self.__berekendeUitstoot = uitstoot

        def getBoete(self):
                return self.__boete
        def setBoete(self, boete):
                self.__boete = boete

        def getControle(self):
                return self.__controle
        def setControle(self, controle):
                self.__controle = controle

        def getInspectieFrequentie(self):
                return self.__inspectieFrequentie
        def setInspectieFrequentie(self, inspectieFrequentie):
                self.__inspectieFrequentie = inspectieFrequentie

        def getContactpersoon(self):
                return self.__contactpersoon
        def setContactpersoon(self, contactpersoon):
                self.__contactpersoon = contactpersoon

        def addBezoekrapport(self, bezoekrapport):
                self.__bezoekrapporten.append(bezoekrapport)

    # printen van de gegevens van het bedrijf
        def toonGegevens(self):
                print(f"{self.__code} {self.__naam} {self.__straat} {self.__huisnummer} {self.__postcode} {self.__plaats} {self.__lengte} {self.__breedte}      {self.__maxUitstoot}                 {self.__berekendeUitstoot}              {self.__boete}          {self.__controle}               {self.__inspectieFrequentie}            {self.__contactpersoon}")



   
    
