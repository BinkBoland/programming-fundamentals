#module_metingen 
#import bestanden
import numpy as np
import matplotlib.pyplot as plt

# Bestandsnaam voor gassen
GASSENBESTAND = 'gassen.csv'

def lees_gas_co2():
    """Inlezen CO2 data vanuit het csv-gassenbestand en plotten van de data"""
    #De functie leest data van uit het csv bestand in en wordt dan omgezet naar een 2d-array
    gasarray = (np.loadtxt(GASSENBESTAND, delimiter=',', skiprows=1, usecols=2)).reshape((100, 100))
    # Afdrukken van de 2D-array
    print(gasarray)
    #de functie plot de gegevens m.b.v. Matplotlib
    plt.imshow(gasarray)
    #de functie voegt een kleurbalk toe 
    plt.colorbar()
    #de functie print het plot 
    plt.show()