#importeren ander modules en libraries 
import Module_gassen_v2 as gs 
import numpy as np

#constanten maken voor bestanden 
gassen_bestand = "gassen.csv"
bedrijvenbestand = "bedrijven.txt" 

lijst_bedrijven = []
#vaststellen gegevens 
drempelwaarde = 7000

#inlezen data 
gassen_data = np.loadtxt(gassen_bestand, delimiter=',', skiprows=1)

#coordinaten met te hoge uitstoot vinden
Coordinaten_met_te_hoge_uitstoot = gs.vind_te_hoge_uitstoot(gassen_data, drempelwaarde)

#functie voor het inlezen van bedrijfsgegevens uit het tekstbestand 
def lees_bedrijven():
    """Inlezen van het tekstbestand met de bedrijfsgegevens"""
    try:
        with open(bedrijvenbestand, mode='r') as bedrijven:
            for record in bedrijven:
                # Uitpakken van de velden uit het record
                code = record[0:4]
                naam = record[4:24]
                straat = record[24:44]
                huisnummer = record[44:59]
                postcode = record[59:66]
                plaats = record[66:80]
                lengte = round(int(record[87:89]), 2)  # Rond het getal af op 2 decimalen
                breedte = round(int(record[89:93]), 2)  # Rond het getal af op 2 decimalen
                maxUitstoot = round(int(record[93:99]), 2)  # Rond het getal af op 2 decimalen
                controle = record[135:138]
                inspectieFrequentie = record[138:141]
                contactpersoon = record[141:160]

                # Creëer een Bedrijf-object en voeg het toe aan de lijst_bedrijven
                bedrijf = Bedrijf(code, naam, straat, huisnummer, postcode, plaats, lengte, breedte, maxUitstoot, controle, inspectieFrequentie, contactpersoon)
        return 0
    except FileNotFoundError:
        return 1

#deze functie gaat op zoek naar het onbekende bedrijf dat een te hoge uitstoot heeft. 
def vindOnbekendeBedrijven():
    
    bekende_coordinaten = [(bedrijf.getLengte(), bedrijf.getBreedte()) for bedrijf in lijst_bedrijven]
    onbekende_coordinaten = [coor for coor in Coordinaten_met_te_hoge_uitstoot if coor not in bekende_coordinaten]

    if not onbekende_coordinaten:
        print("Alle bedrijven met hoge uitstoot zijn bekend.")
    else:
        print("Onbekende bedrijven met hoge uitstoot gevonden op de volgende coördinaten:")
        for coor in onbekende_coordinaten:
            uitstoot = gs.bereken_uitstoot(coor[0], coor[1])
            uitstoot_1e_laag = gs.bereken_uitstoot_laag1(coor[0], coor[1])
            uitstoot_2e_laag = gs.bereken_uitstoot_laag2(coor[0], coor[1])
            uitstoot_totaal = round(uitstoot + uitstoot_1e_laag + uitstoot_2e_laag, 2)

            print(f"Coördinaten: {coor[0]}, {coor[1]}, Totale Uitstoot: {uitstoot_totaal}")


class Bedrijf:
    """Class voor bedrijfsgegevens"""
    def __init__(self, code, naam='', straat='', huisnummer='', postcode='', plaats='', lengte='', breedte='', maxUitstoot='', controle='', inspectieFrequentie='', contactpersoon='', berekendeUitstoot='', boete=''):
        global lijst_bedrijven

        # Initialisatie van de attributen
        self.__code = code
        self.__naam = naam
        self.__straat = straat
        self.__huisnummer = huisnummer
        self.__postcode = postcode
        self.__plaats = plaats
        self.__lengte = lengte
        self.__breedte = breedte
        self.__maxUitstoot = maxUitstoot
        self.__berekendeUitstoot = berekendeUitstoot
        self.__boete = boete
        self.__controle = controle
        self.__inspectieFrequentie = inspectieFrequentie
        self.__contactpersoon = contactpersoon
        self.__bezoekrapporten = []
        lijst_bedrijven.append(self)

    #get en set attributen
    def getCode(self):
        return self.__code
    def setCode(self, code):
        self.__code = code

    def getNaam(self):
        return self.__naam
    def setNaam(self, naam):
        self.__naam = naam

    def getStraat(self):
        return self.__straat
    def setStraat(self, straat):
        self.__straat = straat

    def getHuisnummer(self):
        return self.__huisnummer
    def setHuisnummer(self, huisnummer):
        self.__huisnummer = huisnummer

    def getPostcode(self):
        return self.__postcode
    def setPostcode(self, postcode):
        self.__postcode = postcode

    def getPlaats(self):
        return self.__plaats
    def setPlaats(self, plaats):
        self.__plaats = plaats

    def getLengte(self):
        return self.__lengte
    def setLengte(self, lengte):
        self.__lengte = lengte

    def getBreedte(self):
        return self.__breedte
    def setBreedte(self, breedte):
        self.__breedte = breedte

    def getMaxUitstoot(self):
        return self.__maxUitstoot
    def setMaxUitstoot(self, maxUitstoot):
        self.__maxUitstoot = maxUitstoot

    def getBerekendeUitstoot(self):
        return self.__berekendeUitstoot
    def setBerekendeUitstoot(self, uitstoot):
        self.__berekendeUitstoot = uitstoot

    def getBoete(self):
        return self.__boete
    def setBoete(self, boete):
        self.__boete = boete

    def getControle(self):
        return self.__controle
    def setControle(self, controle):
        self.__controle = controle

    def getInspectieFrequentie(self):
        return self.__inspectieFrequentie
    def setInspectieFrequentie(self, inspectieFrequentie):
        self.__inspectieFrequentie = inspectieFrequentie

    def getContactpersoon(self):
        return self.__contactpersoon
    def setContactpersoon(self, contactpersoon):
        self.__contactpersoon = contactpersoon

    def addBezoekrapport(self, bezoekrapport):
        self.__bezoekrapporten.append(bezoekrapport)

#Functie om de coordinaten van het onbekende bedrijf te tonen en de uitstoot van dit bedrijf te tonen
def tonenOnbekend():
    """Toon onbekende bedrijven met hoge uitstoot"""
    lees_bedrijven()
    vindOnbekendeBedrijven()

