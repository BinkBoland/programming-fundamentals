# module_inspecteurs.py
# constanten
INSPECTEURSBESTAND = '/Users/bolab00/Downloads/Novi education/Python herkansing/inspecteurs.txt'

# lijst met alle inspecteur objecten
lijst_inspecteurs = []   

#klasse voor de inspecteurs:
class Insp:
    def _init_(self, code, naam = "", standplaats = ""):
        global lijst_inspecteurs

        #attributen 
        self.__naam = naam
        self.__standplaats = standplaats
        self.__bezoekrapporten = []
        lijst_inspecteurs.append(self)

#get en set methode voor attributen
def getCode(self):
    return self.__code
def setCode(self,code):
    self.__code = code 

def getNaam(self):
    return self.__naam
def setNaam(self, naam): 
    self.__naam = naam 
def getStandplaats(self):
    return self.__standplaats
def setStandplaats(self, standplaats):
    self.__standplaats = standplaats 

def addBezoekrapport(self, bezoekraport):
    self.__bezoekrapport.append(bezoekraport)

def toonGegevens(self):
    #printen van inspecteursgegeven
    print(self.__code + '', self.__naam, self.__standplaats)


# Functie om inspecteursgegevens in te lezen
def lees_inspecteurs():
    """Inlezen van het tekstbestand met de inspecteursgegevens"""
    try:
        with open(INSPECTEURSBESTAND, mode='r') as inspecteurs:
            for record in inspecteurs:
                # Uitpakken van velden uit het record
                code = record[0:3]
                naam = record[4:24]
                standplaats = record[24:44]
                # Creëer een Inspecteur-object en voeg het toe aan de lijst_inspecteurs
                Insp(code, naam, standplaats)
        print('Bestand', INSPECTEURSBESTAND, 'ingelezen')
        return 0
    except FileNotFoundError:
        print('Bestand', INSPECTEURSBESTAND, 'niet gevonden')
        return 1

# Functie om inspecteurs weer te geven
def toon_inspecteurs():
    """Maak een overzicht van alle inspecteursgegevens"""
    print("        Overzicht inspecteurs")
    print("        =====================\n")
    print("Code Naam                 Standplaats")
    print("---- -------------------- --------------------")

    for inspecteur in lijst_inspecteurs:
        inspecteur.toonGegevens()

