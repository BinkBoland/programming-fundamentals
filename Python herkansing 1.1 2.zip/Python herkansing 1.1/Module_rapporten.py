#constanete maken voor bestanden die als .txt bestand geimplementeerd worden
#het pad naar het bestand bezoekrapporten.txt is veranderd 
bezoekrapporten_bestand = 'bezoekrapporten.txt'

#lijst om rapport-objecten op te kunnen slaan 
lijst_bezoekrapporten = []

# een klasse voor de bezoekrapporten
class Bezoekrapport:
    def __init__(self, inspecteur, bedrijf='', bezoekdatum='', datum_opstellen='', status='', opmerkingen=''):
        global lijst_bezoekrapporten

        # Initialisatie van attributen
        self.__inspecteur = inspecteur
        self.__bedrijf = bedrijf
        self.__bezoekdatum = bezoekdatum
    
        self.__datum_opstellen = datum_opstellen
        self.__status = status
        self.__opmerkingen = opmerkingen
        lijst_bezoekrapporten.append(self)

    # Getter- en setter-methoden voor attributen
    def getInspecteur(self):
        return self.__inspecteur

    def setInspecteur(self, inspecteur):
        self.__inspecteur = inspecteur

    def getBedrijf(self):
        return self.__bedrijf

    def setBedrijf(self, bedrijf):
        self.__bedrijf = bedrijf

    def getBezoekdatum(self):
        return self.__bezoekdatum

    def setBezoekdatum(self, bezoekdatum):
        self.__bezoekdatum = bezoekdatum

    def getDatumOpstellen(self):
        return self.__datum_opstellen

    def setDatumOpstellen(self, datum_opstellen):
        self.__datum_opstellen = datum_opstellen

    def getStatus(self):
        return self.__status

    def setStatus(self, status):
        self.__status = status

    def getOpmerkingen(self):
        return self.__opmerkingen

    def setOpmerkingen(self, opmerkingen):
        self.__opmerkingen = opmerkingen

    def toonGegevens(self):
        # Afdrukken van bezoekrapportgegevens
        print(self.__inspecteur, '     ', self.__bedrijf, ' ', self.__bezoekdatum, self.__datum_opstellen, '   ',
              self.__status, self.__opmerkingen)
        
#functie voor het inlezen van bezoektrapporten 
def lees_bezoekrapporten():
    try: 
     with open(bezoekrapporten_bestand, mode='r') as bezoekrapporten:
            for record in bezoekrapporten:
                # Uitpakken van velden uit het record
                inspecteur = record[0:3]
                bedrijf = record[3:8]
                bezoekdatum = record[8:20]
                datum_opstellen = record[20:30]
                status = record[30:42]
                opmerkingen = record[42:75]
                # Creëer een Bezoekrapport-object en voeg het toe aan de lijst_bezoekrapporten
                Bezoekrapport(inspecteur, bedrijf, bezoekdatum, datum_opstellen, status, opmerkingen)
            print('Bestand', bezoekrapporten, 'ingelezen')
            return 0
    except FileNotFoundError:
        print('Bestand', bezoekrapporten_bestand, 'niet gevonden')
        return 1
    
def toon_bezoekrapporten():
    print("        Overzicht bezoekrapporten")
    print("        =====================\n")
    print("Inspecteur Bedrijf Bezoekdatum Datum opstellen Status      Opmerkingen")
    print("---------- ------- ----------- --------------- ----------  ---------------------------------")

    for bezoekrapport in lijst_bezoekrapporten:
        bezoekrapport.toonGegevens()

#de volgende functie moet een bezoekrapport tonen aan de hand van een code die bij een inspecteur past, er worden dan bezoekrapporten getoond van de inspecteur met de code die is ingetoetst.
    
def Zoek_Inspecteur_code():
    inspecteur_code = input('Voer de inspecteurcode in:  ')

    gevonden_rapporten = []

    for bezoekrapport in lijst_bezoekrapporten:
        if bezoekrapport.getInspecteur() == inspecteur_code:
            gevonden_rapporten.append(bezoekrapport)

    if gevonden_rapporten:
        print(f"        Overzicht bezoekrapporten van inspecteurcode: {inspecteur_code} ")
        print("        =====================\n")
        print("Inspecteur Bedrijf Bezoekdatum Datum opstellen Status      Opmerkingen")
        print("---------- ------- ----------- --------------- ----------  ---------------------------------")
        for bezoekrapport in gevonden_rapporten:
            bezoekrapport.toonGegevens()
        return True
    else:
        print(f"Inspecteurcode {inspecteur_code} niet gevonden.")
        return False

# functie om een bezoekrapport te zoeken voor een bedrijf in plaats van een inspecteur.
def zoek_bedrijf_code():
    bedrijf_code = input("Voer de bedrijfcode in: ")

    gevonden_bezoekrapporten = []

    for bezoekrapport in lijst_bezoekrapporten:
        if bedrijf_code in bezoekrapport.getBedrijf():
            gevonden_bezoekrapporten.append(bezoekrapport)

    if gevonden_bezoekrapporten:
        print(f"        Overzicht bezoekrapporten van bedrijfcode: {bedrijf_code} ")
        print("        =====================\n")
        print("Inspecteur Bedrijf Bezoekdatum Datum opstellen Status      Opmerkingen")
        print("---------- ------- ----------- --------------- ----------  ---------------------------------")
        for bezoekrapport in gevonden_bezoekrapporten:
            bezoekrapport.toonGegevens()
        return True
    else:
        print(f"Bedrijfcode {bedrijf_code} niet gevonden.")
        return False 